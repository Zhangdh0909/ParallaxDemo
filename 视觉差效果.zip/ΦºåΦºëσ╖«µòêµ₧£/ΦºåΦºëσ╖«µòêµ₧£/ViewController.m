//
//  ViewController.m
//  视觉差效果
//
//  Created by Mac on 16/11/22.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "ViewController.h"
#import "Cell.h"
@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (nonatomic,strong) NSArray * datas;
@end

@implementation ViewController

static NSString * const cellIdentifierKey = @"cellIdentifierKey";

- (NSArray *)datas{
    if (!_datas) {
        NSMutableArray * arr = [NSMutableArray array];
        for (int i = 0; i < 20; i++) {
//            [arr addObject:[UIImage imageNamed:[NSString stringWithFormat:@"shijuecha%d",i % 10 + 1]]];
            [arr addObject:[UIImage pgq_imageCompressForWidth: [UIImage imageNamed:[NSString stringWithFormat:@"shijuecha%d",i % 10 + 1] ] targetWidth:[UIScreen mainScreen].bounds.size.width]];
        }
        _datas = [NSArray arrayWithArray:arr];
    }
    return _datas;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableview registerNib:[UINib nibWithNibName:@"Cell" bundle:nil] forCellReuseIdentifier:cellIdentifierKey];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//滚动监听
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    // 获取表视图的可见单元格。(可见的视图)
    NSArray *visibleCells = [self.tableview visibleCells];
    
    for (Cell *cell in visibleCells) {
        //可见视图设置->背景图片y值
        [cell cellOnTableView:self.tableview didScrollView:self.view];
    }
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSLog(@"%ld",self.datas.count);
    return self.datas.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    Cell * cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifierKey forIndexPath:indexPath];
    
    [cell cellImage:_datas[indexPath.row]];
    
    return cell;
}

@end

@implementation UIImage (ViewController)

+(UIImage * _Nullable)pgq_imageCompressForWidth:(UIImage * _Nonnull)sourceImage targetWidth:(CGFloat)defineWidth{
    //根据原图片计算值压缩后的尺寸
    CGSize imageSize = sourceImage.size;
    CGFloat bili = imageSize.width / imageSize.height;
    CGFloat width = defineWidth * 2;
    CGFloat height = width * bili;
    
    //开启绘图
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(width, height), 1, 1);
    
    //绘图到当前上下文
    [sourceImage drawInRect:CGRectMake(0, 0, width, height)];
    
    //获取新图片
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    //关闭图片绘制
    UIGraphicsEndImageContext();
    
    //返回图片
    return newImage;
}

@end
