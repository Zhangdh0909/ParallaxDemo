//
//  ViewController.h
//  视觉差效果
//
//  Created by Mac on 16/11/22.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end


@interface UIImage (ViewController)
+(UIImage * _Nullable)pgq_imageCompressForWidth:(UIImage * _Nonnull)sourceImage targetWidth:(CGFloat)defineWidth;
@end
