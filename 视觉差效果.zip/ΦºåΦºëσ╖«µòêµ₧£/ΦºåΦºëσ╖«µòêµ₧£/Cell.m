//
//  Cell.m
//  视觉差效果
//
//  Created by Mac on 16/11/22.
//  Copyright © 2016年 Mac. All rights reserved.
//

#import "Cell.h"

@implementation Cell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.clipsToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)cellImage:(UIImage *)image{
    self.backImage.image = image;
}

- (void)cellOnTableView:(UITableView *)tableView didScrollView:(UIView *)view{
    
    //将cell的frame转换成View的Frame
    CGRect rect = [tableView convertRect:self.frame toView:view];
    
    //视图的Frame的一半 减去 所看到的每个Cell的Y（获取滚动的值）
    //以屏幕中心为0 获取能看到每个cell离中心点的值
    float distanceCenter = CGRectGetHeight(view.frame)*0.5 - CGRectGetMinY(rect);
    
    
    //图片的高度 - cell的高度 = 图片超出cell的高度部分
    float difference = CGRectGetHeight(self.backImage.frame) - CGRectGetHeight(self.frame);
    
    float imageMove = (distanceCenter / CGRectGetHeight(view.frame)) * difference;
    
    //旧的图片Frame
    CGRect imageRect = self.backImage.frame;
    
    //计算新的Y值
    imageRect.origin.y = imageMove - (difference *0.5);
    
    //赋值
    self.backImage.frame = imageRect;
    
}

@end


